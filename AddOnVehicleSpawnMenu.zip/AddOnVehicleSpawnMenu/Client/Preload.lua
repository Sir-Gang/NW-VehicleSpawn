AOVSM = {}

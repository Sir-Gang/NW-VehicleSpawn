Categories = {
	-- {
	-- 	name = "Regular Cars",
	-- 	subCategories = {
	-- 		[0] = GetLabelText('VEH_CLASS_0'),	--Compacts
	-- 		[1] = GetLabelText('VEH_CLASS_1'),	--Sedans
	-- 		[2] = GetLabelText('VEH_CLASS_2'),	--SUVs
	-- 		[3] = GetLabelText('VEH_CLASS_3'),	--Coupes
	-- 		[4] = GetLabelText('VEH_CLASS_4'),	--Muscle
	-- 		[5] = GetLabelText('VEH_CLASS_5'),	--Sports Classics
	-- 		[6] = GetLabelText('VEH_CLASS_6'),	--Sports
	-- 		[7] = GetLabelText('VEH_CLASS_7'),	--Super
	-- 		[8] = GetLabelText('VEH_CLASS_8'),	--Motorcycles
	-- 		[9] = GetLabelText('VEH_CLASS_9'),	--Off-road
	-- 		[10] = GetLabelText('VEH_CLASS_10'),	--Industrial
	-- 		[11] = GetLabelText('VEH_CLASS_11'),	--Utility
	-- 		[12] = GetLabelText('VEH_CLASS_12'),	--Vans
	-- 		[13] = GetLabelText('VEH_CLASS_13'),	--Cycles
	-- 		[14] = GetLabelText('VEH_CLASS_14'),	--Boats
	-- 		[15] = GetLabelText('VEH_CLASS_15'),	--Helicopters
	-- 		[16] = GetLabelText('VEH_CLASS_16'),	--Planes
	-- 		[17] = GetLabelText('VEH_CLASS_17'),	--Service
	-- 		[18] = GetLabelText('VEH_CLASS_18'),	--Emergency
	-- 		[19] = GetLabelText('VEH_CLASS_19'),	--Military
	-- 		[20] = GetLabelText('VEH_CLASS_20'),	--Commercial
	-- 		[21] = GetLabelText('VEH_CLASS_21'),	--Trains
	-- 		[22] = GetLabelText('TRAILER'), 		--Trailers
	-- 	},
	-- },
	-- {
	-- 	name = "EXAMPLE MUSCLE",
	-- 	subCategories = {
	-- 		[23] = 'VEHICLE SUBCATEGORY',
	-- 	},
	-- },
	{
	
}